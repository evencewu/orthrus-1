#!/bin/bash

# run with riviz or not
roslaunch yesense_imu yesense_rviz.launch

