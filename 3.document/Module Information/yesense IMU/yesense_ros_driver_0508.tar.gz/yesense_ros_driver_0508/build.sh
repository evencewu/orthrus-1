#!/bin/bash

# step 1: compile whole project ...
catkin_make

# step 2: source project environments ...
source devel/setup.bash

